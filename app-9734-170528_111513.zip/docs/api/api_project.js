define({
  "name": "",
  "version": "0.0.0",
  "description": "",
  "sampleUrl": false,
  "apidoc": "0.2.0",
  "generator": {
    "name": "apidoc",
    "time": "2017-05-27T20:48:38.952Z",
    "url": "http://apidocjs.com",
    "version": "0.16.1"
  }
});

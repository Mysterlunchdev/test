/*
	author: Markus Kuhn
	require all models in /model and expose it to the express application
*/

require('../models/users');

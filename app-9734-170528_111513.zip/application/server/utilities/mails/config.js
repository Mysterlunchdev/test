/**
 * author - Markus Kuhn
 * copyright 360 OPG GmbH Essen
 *
 * config file 
 */


module.exports = {
	host: 'blue.host-care.com',
	port: 465,
	auth: {
		user: 'markus.kuhn@mahlzeit.co',
		pass: '1ki6s5ivf'
	},
    secure:true,
    // tls: {rejectUnauthorized: false}
}
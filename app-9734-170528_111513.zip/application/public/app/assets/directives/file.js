/**
 * templatedirective for file attachments 
 */

angular.module('app').directive('fileAttachment', function() {
	return {
		templateUrl: '/partials/common/directives/fileAttachment'
	};
});
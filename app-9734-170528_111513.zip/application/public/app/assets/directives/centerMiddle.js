app.directive('centerMiddle', function($timeout) {
	return {
		link: function(scope, element, attrs) {
			// iteration is complete, do whatever post-processing
			// is necessary
			// $timeout(function() {
			// 	$timeout(function(){
			// 		setInterval(function() {
			// 			console.log("timeouet ");
						
			// 			console.log(element.prop('offsetHeight'));
			// 		},1000);

			// 		// var height = element.parent().parent()[0].offsetHeight/2-element.offsetHeight/2;
			// 		// element.css('margin-top', height +'px');
					
			// 	},0)
			
			// },0)
			
		}
	}
});
